import mysql.connector
import os
import shutil
import random

# MySQL database configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'root',
    'database': 'mura_humerus',
    'auth_plugin': 'mysql_native_password'
}

# Percentage of images to use for testing
test_split_percentage = 0.2

# Paths for folders
base_directory = r'D:\NCI_DA_Materials\SEM_3'
train_directory = os.path.join(base_directory, 'TrainingImagesHM')
test_directory = os.path.join(base_directory, 'TestImagesHM')

# Create positive and negative subfolders for train and test
train_positive_dir = os.path.join(train_directory, 'positive')
train_negative_dir = os.path.join(train_directory, 'negative')
test_positive_dir = os.path.join(test_directory, 'positive')
test_negative_dir = os.path.join(test_directory, 'negative')

for folder in [train_positive_dir, train_negative_dir, test_positive_dir, test_negative_dir]:
    os.makedirs(folder, exist_ok=True)

# Connect to the database
conn = mysql.connector.connect(**db_config)
cursor = conn.cursor()

# Query to fetch training images paths and labels
query = "SELECT image_path, is_fractured, patient_id FROM humerus_train_images"
cursor.execute(query)
rows = cursor.fetchall()

# Shuffle rows for random test split
random.shuffle(rows)

# Calculate number of test images
num_test_images = int(len(rows) * test_split_percentage)

# Counters
train_count = 0
test_count = 0

# Loop through each row and copy images to respective directories
for i, (image_path, is_fractured, patient_id) in enumerate(rows):
    # Determine source path of the image
    source_path = os.path.join(base_directory, image_path)  # Adjust base path as needed

    # Determine if this image goes into the test set
    if i < num_test_images:
        # Destination directory for test set
        destination_dir = test_positive_dir if is_fractured else test_negative_dir
        test_count += 1
    else:
        # Destination directory for training set
        destination_dir = train_positive_dir if is_fractured else train_negative_dir
        train_count += 1

    # Create patient-wise subfolder in the destination
    patient_folder = os.path.join(destination_dir, f'patient_{patient_id}')
    os.makedirs(patient_folder, exist_ok=True)

    # Copy image if it exists
    if os.path.exists(source_path):
        destination_path = os.path.join(patient_folder, os.path.basename(source_path))
        shutil.copy(source_path, destination_path)
    else:
        print(f"Image does not exist: {source_path}")

# Print counts
print(f"Total training images copied: {train_count}")
print(f"Total test images copied: {test_count}")

# Close the database connection
cursor.close()
conn.close()

print("Image extraction for train and test sets completed.")
