import mysql.connector
import os
import pandas as pd

# MySQL database configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'root',
    'database': 'mura_humerus',
    'auth_plugin': 'mysql_native_password'
}

# Establish connection to the database
conn = mysql.connector.connect(**db_config)
cursor = conn.cursor()


# Function to create tables if they don't exist
def create_table(table_name):
    create_query = f'''
    CREATE TABLE IF NOT EXISTS {table_name} (
        id INT AUTO_INCREMENT PRIMARY KEY,
        image_path VARCHAR(255) NOT NULL,
        is_fractured BOOLEAN NOT NULL,
        study VARCHAR(50) NOT NULL,
        patient_id VARCHAR(50) NOT NULL
    )
    '''
    cursor.execute(create_query)
    conn.commit()


# Function to insert data from a CSV file into the train or valid table
def insert_data_from_csv(csv_file, table_name):
    # Check and create the table if it doesn't exist
    create_table(table_name)

    # Load CSV data
    df = pd.read_csv(csv_file)
    for index, row in df.iterrows():
        dir_path = row['path']  # Directory containing images
        is_fractured = row['label']  # Label indicating fracture (0 or 1)

        # Construct full path based on the directory structure
        full_dir_path = os.path.join('D:\\NCI_DA_Materials\\SEM_3', dir_path)

        # Check if the directory exists
        if os.path.exists(full_dir_path):
            # Iterate over each image in the directory
            for image_name in os.listdir(full_dir_path):
                # Complete image path
                image_path = os.path.join(dir_path, image_name)

                # Extract patient ID and study type from the path structure
                patient_id = os.path.basename(os.path.dirname(dir_path))
                study_type = 'positive' if is_fractured == 1 else 'negative'

                # Insert image record into the specified table
                insert_query = f'''
                INSERT INTO {table_name} (image_path, is_fractured, study, patient_id)
                VALUES (%s, %s, %s, %s)
                '''
                cursor.execute(insert_query, (image_path, is_fractured, study_type, patient_id))
        else:
            print(f"Directory does not exist: {full_dir_path}")

    conn.commit()


# Paths to your CSV files
train_labels_path = r'D:\NCI_DA_Materials\SEM_3\MURA-v1.2\train_labeled_shoulder.csv'
valid_labels_path = r'D:\NCI_DA_Materials\SEM_3\MURA-v1.2\valid_labeled_shoulder.csv'

# Insert data from CSVs into respective tables
insert_data_from_csv(train_labels_path, 'shoulder_train_images')
insert_data_from_csv(valid_labels_path, 'shoulder_valid_images')

# Close the connection
cursor.close()
conn.close()
