import mysql.connector
import os
import shutil

# MySQL database configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'root',
    'database': 'mura_humerus',
    'auth_plugin': 'mysql_native_password'
}

# Establish connection to the database
conn = mysql.connector.connect(**db_config)
cursor = conn.cursor()

# Create the base directory for training images
base_directory = r'D:\NCI_DA_Materials\SEM_3\TrainingImagesHumerus'
positive_dir = os.path.join(base_directory, 'positive')
negative_dir = os.path.join(base_directory, 'negative')

# Create directories if they don't exist
os.makedirs(positive_dir, exist_ok=True)
os.makedirs(negative_dir, exist_ok=True)

# Query to fetch training data (including patient_id)
query = "SELECT image_path, is_fractured, patient_id FROM humerus_train_images"
cursor.execute(query)

# Fetch all rows
rows = cursor.fetchall()

# Initialize counters for fractured and non-fractured images
positive_count = 0
negative_count = 0

# Loop through each row and copy images to respective directories
for image_path, is_fractured, patient_id in rows:
    # Determine the source path for the image D:\NCI_DA_Materials\SEM_3
    source_path = os.path.join('D:\\NCI_DA_Materials\\SEM_3', image_path)  # Base path to your images

    # Log the image path
    print(f"Processing: {source_path}")

    # Check if the image file exists
    if os.path.exists(source_path):
        # Decide the destination based on whether it's fractured or not
        if is_fractured:
            # Create a new filename to avoid overwriting
            new_filename = f"{positive_count + 1}_{os.path.basename(source_path)}"
            # Create patient-wise directory
            patient_folder = os.path.join(positive_dir, f'patient_{patient_id}')
            os.makedirs(patient_folder, exist_ok=True)
            destination_path = os.path.join(patient_folder, new_filename)
            shutil.copy(source_path, destination_path)
            positive_count += 1
        else:
            # Create a new filename to avoid overwriting
            new_filename = f"{negative_count + 1}_{os.path.basename(source_path)}"
            # Create patient-wise directory
            patient_folder = os.path.join(negative_dir, f'patient_{patient_id}')
            os.makedirs(patient_folder, exist_ok=True)
            destination_path = os.path.join(patient_folder, new_filename)
            shutil.copy(source_path, destination_path)
            negative_count += 1
    else:
        print(f"Image does not exist: {source_path}")

# Print out the counts of images copied
print(f"Total positive images copied: {positive_count}")
print(f"Total negative images copied: {negative_count}")

# Close the connection
cursor.close()
conn.close()

print("Image extraction completed.")
