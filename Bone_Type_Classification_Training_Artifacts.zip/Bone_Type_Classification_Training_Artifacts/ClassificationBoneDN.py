from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.layers import Dense, Flatten, Dropout, BatchNormalization
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import load_model, Sequential
from tensorflow.keras.optimizers import Adam

# 1. Load the pre-trained body part model (this classifies images as Humerus or Shoulder)
body_part_model = load_model('body_part_model.h5')

# 2. Unfreeze more layers of the body part model (Optional, to allow fine-tuning)
for layer in body_part_model.layers[:100]:  # Unfreeze the first 100 layers
    layer.trainable = False

for layer in body_part_model.layers[100:]:  # Unfreeze layers from the 101st layer
    layer.trainable = True

# 3. Create a new model for fracture classification
fracture_model = Sequential([
    body_part_model,  # Use body part model as a feature extractor
    Flatten(),
    BatchNormalization(),  # Batch normalization for better performance
    Dropout(0.3),  # Adjusted dropout rate
    Dense(128, activation='relu'),  # Increased number of units
    Dropout(0.3),  # Another Dropout for regularization
    Dense(2, activation='softmax')  # 2 classes: fractured vs non-fractured
])

# 4. Compile the fracture classification model with a smaller learning rate
fracture_model.compile(optimizer=Adam(learning_rate=1e-4), loss='categorical_crossentropy', metrics=['accuracy'])

# 5. Prepare Image Data Generators for training and validation with advanced augmentation
train_datagen = ImageDataGenerator(
    rescale=1./255,
    rotation_range=30,
    width_shift_range=0.3,
    height_shift_range=0.3,
    shear_range=0.3,
    zoom_range=0.3,
    horizontal_flip=True,
    fill_mode='nearest'
)

valid_datagen = ImageDataGenerator(rescale=1./255)

train_generator = train_datagen.flow_from_directory(
    r'D:\NCI_DA_Materials\SEM_3\Combined_TrainingTesting\TrainingImagesBoth',
    target_size=(128, 128),
    batch_size=32,
    class_mode='categorical'
)

valid_generator = valid_datagen.flow_from_directory(
    r'D:\NCI_DA_Materials\SEM_3\Combined_TrainingTesting\ValidImagesBoth',
    target_size=(128, 128),
    batch_size=32,
    class_mode='categorical'
)

# 6. Callbacks for better training control
early_stopping = EarlyStopping(monitor='val_loss', patience=7, restore_best_weights=True)
reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=5, min_lr=0.00001)

# 7. Train the fracture classification model
history = fracture_model.fit(
    train_generator,
    epochs=30,
    validation_data=valid_generator,
    callbacks=[early_stopping, reduce_lr]
)

# 8. Save the trained model for future use
fracture_model.save('fracture_classification_model_improved.h5')

# Optionally, you can print the model summary
fracture_model.summary()
