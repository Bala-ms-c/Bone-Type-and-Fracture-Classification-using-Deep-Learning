import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, Flatten
from tensorflow.keras.applications import DenseNet169
import matplotlib.pyplot as plt

# Paths to training and validation directories
train_dir = r'D:\NCI_DA_Materials\SEM_3\TrainingImagesHumerus_Testing'
valid_dir = r'D:\NCI_DA_Materials\SEM_3\ValidImagesHumerus_Testing'

# ImageDataGenerator with data augmentation for the training set
train_datagen = ImageDataGenerator(
    rescale=1.0/255,
    rotation_range=20,       # Rotate images up to 20 degrees
    width_shift_range=0.1,   # Shift images horizontally by up to 10%
    height_shift_range=0.1,  # Shift images vertically by up to 10%
    shear_range=0.15,        # Shear angle up to 15 degrees
    zoom_range=0.15,         # Zoom in or out by 15%
    horizontal_flip=True,    # Randomly flip images horizontally
    fill_mode='nearest'      # Fill in any new pixels created
)

# Validation data generator without augmentation, only rescaling
valid_datagen = ImageDataGenerator(rescale=1.0/255)

# Image generators for loading the images
train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(128, 128),  # Resize all images to 128x128
    batch_size=32,
    class_mode='binary'      # Binary classification
)

valid_generator = valid_datagen.flow_from_directory(
    valid_dir,
    target_size=(128, 128),
    batch_size=32,
    class_mode='binary'
)

# Load the DenseNet169 model with pretrained weights from ImageNet
base_model = DenseNet169(weights='imagenet', include_top=False, input_shape=(128, 128, 3))

# Freeze the base model layers to avoid training them
for layer in base_model.layers:
    layer.trainable = False

# Add custom layers on top of the DenseNet model
model = Sequential([
    base_model,
    Flatten(),
    Dense(128, activation='relu'),
    Dropout(0.5),
    Dense(1, activation='sigmoid')  # Sigmoid for binary classification
])

# Compile the model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Train the model and store the history
history = model.fit(
    train_generator,
    epochs=30,
    validation_data=valid_generator
)

# Save the model
model.save(r'C:\Users\BillJ\PycharmProjects\Code_bone\densenet169_augmented_model.h5')

# Plot training and validation accuracy and loss
plt.figure(figsize=(12, 4))

# Plot accuracy
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Training Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title('Model Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()

# Plot loss
plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Model Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()

plt.show()
