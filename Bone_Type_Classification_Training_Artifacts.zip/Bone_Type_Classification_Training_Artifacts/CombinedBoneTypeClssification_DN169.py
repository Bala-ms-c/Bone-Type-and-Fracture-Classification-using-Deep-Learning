import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, Flatten
from tensorflow.keras.applications import DenseNet169
import matplotlib.pyplot as plt

# Paths to training, validation, and test directories
train_dir = r'D:\NCI_DA_Materials\SEM_3\Combined_TrainingTesting\TrainingImagesBoth'
valid_dir = r'D:\NCI_DA_Materials\SEM_3\Combined_TrainingTesting\ValidImagesBoth'
test_dir = r'D:\NCI_DA_Materials\SEM_3\Combined_TrainingTesting\TestImagesBoth_big'

# Image size and batch size
img_size = (128, 128)
batch_size = 128

### TASK 1: Humerus vs. Shoulder Classification ###
# Data generators for body part classification
body_part_train_gen = ImageDataGenerator(rescale=1.0 / 255)
body_part_valid_gen = ImageDataGenerator(rescale=1.0 / 255)

body_part_train = body_part_train_gen.flow_from_directory(
    directory=train_dir,
    target_size=img_size,
    batch_size=batch_size,
    classes=["Humerus", "Shoulder"],  # Class names for humerus vs. shoulder
    class_mode="binary"  # Binary classification
)

body_part_valid = body_part_valid_gen.flow_from_directory(
    directory=valid_dir,
    target_size=img_size,
    batch_size=batch_size,
    classes=["Humerus", "Shoulder"],
    class_mode="binary"
)

# Load DenseNet169 base model
base_model_body_part = DenseNet169(weights="imagenet", include_top=False, input_shape=(128, 128, 3))
for layer in base_model_body_part.layers:
    layer.trainable = False

# Build model for body part classification
model_body_part = Sequential([
    base_model_body_part,
    Flatten(),
    Dense(128, activation="relu"),
    Dropout(0.5),
    Dense(1, activation="sigmoid")  # Sigmoid for binary output
])

# Compile the model
model_body_part.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])

# Train the model
history_body_part = model_body_part.fit(
    body_part_train,
    epochs=10,
    validation_data=body_part_valid
)

# Save the model
model_body_part.save(r'C:\Users\BillJ\PycharmProjects\Code_bone\body_part_model.h5')

# Plot accuracy and loss for body part classification
plt.figure(figsize=(12, 4))
plt.subplot(1, 2, 1)
plt.plot(history_body_part.history["accuracy"], label="Training Accuracy")
plt.plot(history_body_part.history["val_accuracy"], label="Validation Accuracy")
plt.title("Body Part Classification Accuracy")
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(history_body_part.history["loss"], label="Training Loss")
plt.plot(history_body_part.history["val_loss"], label="Validation Loss")
plt.title("Body Part Classification Loss")
plt.legend()
plt.show()