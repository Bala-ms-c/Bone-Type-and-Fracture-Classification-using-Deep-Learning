from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
import cv2
import numpy as np
import matplotlib.pyplot as plt

# Function to preprocess images using Canny edge detection and Histogram Equalization
def preprocess_with_canny(image):
    # Ensure the image is in the proper dtype for OpenCV
    if image.dtype != np.uint8:
        image = (image * 255).astype(np.uint8)  # Rescale if image is normalized (0-1)
    # Convert to grayscale
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    # Apply Histogram Equalization
    equalized_image = cv2.equalizeHist(gray_image)
    # Apply Canny Edge Detection
    edges = cv2.Canny(equalized_image, threshold1=100, threshold2=200)
    # Convert edges back to 3-channel (optional, depends on MobileNet input needs)
    edges_rgb = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)
    return edges_rgb

# Custom data generator with preprocessing
def preprocess_data_generator(generator, batch_size):
    while True:
        batch_x, batch_y = next(generator)
        batch_x_processed = np.array([preprocess_with_canny(image) for image in batch_x])
        yield batch_x_processed, batch_y

# Load MobileNetV2 model with ImageNet weights
mobilenet_base = MobileNetV2(weights='imagenet', include_top=False, input_shape=(128, 128, 3), pooling='avg')

# Freeze the layers of MobileNetV2
for layer in mobilenet_base.layers:
    layer.trainable = False

# Add final classification layer
output_layer = mobilenet_base.output
output_layer = Dense(2, activation="softmax", name="final_output")(output_layer)

# Build the complete model
fracture_model = Model(inputs=mobilenet_base.input, outputs=output_layer)

# Compile the model
fracture_model.compile(optimizer=Adam(learning_rate=1e-4), loss='categorical_crossentropy', metrics=['accuracy'])

# Define ImageDataGenerators for training and validation
train_datagen = ImageDataGenerator(
    rescale=1./255,
    rotation_range=30,
    width_shift_range=0.3,
    height_shift_range=0.3,
    shear_range=0.3,
    zoom_range=0.3,
    horizontal_flip=True,
    fill_mode='nearest'
)

valid_datagen = ImageDataGenerator(rescale=1./255)

# Generate training data
train_generator = train_datagen.flow_from_directory(
    r'D:\NCI_DA_Materials\SEM_3\Combined_TrainingTesting\Final_Processed_Data\TrainingImagesBoth',
    target_size=(128, 128),
    batch_size=32,
    class_mode='categorical'
)

# Generate validation data
valid_generator = valid_datagen.flow_from_directory(
    r'D:\NCI_DA_Materials\SEM_3\Combined_TrainingTesting\Final_Processed_Data\ValidImagesBoth',
    target_size=(128, 128),
    batch_size=32,
    class_mode='categorical'
)

# Preprocess data using the custom preprocessing generator
train_data = preprocess_data_generator(train_generator, batch_size=32)
valid_data = preprocess_data_generator(valid_generator, batch_size=32)

# Callbacks for better training control
early_stopping = EarlyStopping(monitor='val_loss', patience=4, restore_best_weights=True)
reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=5, min_lr=0.00001)

# Train the model
history = fracture_model.fit(
    train_data,
    steps_per_epoch=train_generator.samples // train_generator.batch_size,
    validation_data=valid_data,
    validation_steps=valid_generator.samples // valid_generator.batch_size,
    epochs=20,
    callbacks=[early_stopping, reduce_lr]
)

# Save the trained model
fracture_model.save('fracture_classification_mobilenetv2.h5')

# # Print the model summary
# fracture_model.summary()

# Plot training and validation accuracy and loss
plt.figure(figsize=(12, 4))

# Plot accuracy
plt.subplot(1, 2, 1)
plt.plot(history.history["accuracy"], label="Training Accuracy")
plt.plot(history.history["val_accuracy"], label="Validation Accuracy")
plt.title("Fracture Classification Accuracy")
plt.legend()

# Plot loss
plt.subplot(1, 2, 2)
plt.plot(history.history["loss"], label="Training Loss")
plt.plot(history.history["val_loss"], label="Validation Loss")
plt.title("Fracture Classification Loss")
plt.legend()

plt.show()
