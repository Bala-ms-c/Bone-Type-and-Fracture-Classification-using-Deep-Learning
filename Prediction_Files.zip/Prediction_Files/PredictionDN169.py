import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import matplotlib.pyplot as plt
import os
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, classification_report

# Paths to the test images directory
test_dir = r'C:\Users\BALA\Downloads\TestImageHumerus'  # Update this path to your test images directory

# ImageDataGenerator for loading test images as grayscale
test_datagen = ImageDataGenerator(rescale=1.0/255)

# Create a generator for the test images
test_generator = test_datagen.flow_from_directory(
    test_dir,
    target_size=(128, 128),  # Resize all images to 128x128
    batch_size=32,
    color_mode='rgb',  # Load images as grayscale
    class_mode='binary',  # Binary classification
    shuffle=False  # Do not shuffle for predictions
)

# Load the trained DenseNet169 model (modify the input shape in your model if needed)
model = tf.keras.models.load_model(r'C:\Users\BALA\PycharmProjects\HumerusClassification\densenet169_augmented_model_FINAL.h5')

# Print the model summary
model.summary()

# Make predictions
predictions = model.predict(test_generator)
predicted_classes = (predictions > 0.5).astype("int32")  # Convert probabilities to binary classes

# Get the filenames and true labels of test images
filenames = test_generator.filenames
true_labels = test_generator.classes

# Print the predictions and calculate accuracy
correct_predictions = np.sum(predicted_classes.flatten() == true_labels)
total_predictions = len(true_labels)
accuracy = correct_predictions / total_predictions

print(f'Accuracy: {accuracy * 100:.2f}%')

# Show predictions for some images
plt.figure(figsize=(12, 6))
for i in range(min(6, len(filenames))):  # Display up to 6 images
    plt.subplot(2, 3, i + 1)
    img_path = os.path.join(test_dir, filenames[i])
    img = plt.imread(img_path)
    plt.imshow(img, cmap='gray')  # Display as grayscale
    plt.title(f'Predicted: {"Fractured" if predicted_classes[i] == 1 else "Not Fractured"}')
    plt.axis('off')
plt.tight_layout()
plt.show()

# Compute and display confusion matrix
cm = confusion_matrix(true_labels, predicted_classes)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['Not Fractured', 'Fractured'])
disp.plot(cmap=plt.cm.Blues)
plt.show()

# Print classification report (precision, recall, F1-score)
print("\nClassification Report:")
print(classification_report(true_labels, predicted_classes, target_names=['Not Fractured', 'Fractured']))
