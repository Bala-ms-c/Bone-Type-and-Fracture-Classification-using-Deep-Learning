import os
import numpy as np
import pandas as pd
import tensorflow as tf
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.utils import Sequence
from sklearn.metrics import accuracy_score

# Custom image generator for loading and batching images
class CustomImageGenerator(Sequence):
    def __init__(self, image_dir, labels_df, batch_size=32, target_size=(128, 128), shuffle=True):
        self.image_dir = image_dir
        self.labels_df = labels_df
        self.batch_size = batch_size
        self.target_size = target_size
        self.shuffle = shuffle

        # List of image filenames from the DataFrame
        self.filenames = self.labels_df['Filename'].values
        self.indexes = np.arange(len(self.filenames))

        if self.shuffle:
            np.random.shuffle(self.indexes)

    def __len__(self):
        return int(np.floor(len(self.filenames) / self.batch_size))

    def on_epoch_end(self):
        if self.shuffle:
            np.random.shuffle(self.indexes)

    def __getitem__(self, index):
        batch_indexes = self.indexes[index * self.batch_size: (index + 1) * self.batch_size] #Computes which filenames belong to current batch.
        batch_filenames = self.filenames[batch_indexes] #Loads the image and corresponding labels for the batch.

        images = np.array([self.load_image(filename) for filename in batch_filenames]) # holds the image files for the batch.

        # Get labels for the batch (body part and fracture)
        labels_body_part = np.array([self.labels_df[self.labels_df['Filename'] == filename]['Body Part Label'].values[0] for filename in batch_filenames])
        labels_fracture = np.array([self.labels_df[self.labels_df['Filename'] == filename]['Label (Fracture)'].values[0] for filename in batch_filenames])

        # Stack labels for body part and fracture into one array
        labels = np.stack((labels_body_part, labels_fracture), axis=1)

        return tf.convert_to_tensor(images), tf.convert_to_tensor(labels)

    def load_image(self, filename):
        label_row = self.labels_df[self.labels_df['Filename'] == filename]
        body_part = label_row['Body Part Label'].values[0]
        fracture_status = label_row['Label (Fracture)'].values[0]

        if body_part == 0:
            body_part_dir = 'Humerus'
        elif body_part == 1:
            body_part_dir = 'Shoulder'
        else:
            raise ValueError(f"Unknown body part: {body_part}")

        fracture_status_dir = 'positive' if fracture_status == 1 else 'negative'
        image_path = os.path.join(self.image_dir, body_part_dir, fracture_status_dir, filename)

        if not os.path.exists(image_path):
            print(f"Warning: Image file {filename} not found at {image_path}")
            return np.zeros((self.target_size[0], self.target_size[1], 3))

        image = load_img(image_path, target_size=self.target_size)
        image = img_to_array(image) / 255.0
        return image


# Load labels from CSV file
labels_df = pd.read_csv('labels.csv')  # Path to the labels CSV file

# Ensure labels are correctly encoded as numeric values
labels_df['Body Part Label'] = labels_df['Body Part Label'].map({'Humerus': 0, 'Shoulder': 1})
labels_df['Label (Fracture)'] = labels_df['Label (Fracture)'].astype(int)

# Define the image directory where your images are located
image_dir = r'D:\NCI_DA_Materials\SEM_3\Combined_TrainingTesting\TestImagesBoth'

# Initialize the CustomImageGenerator
image_generator = CustomImageGenerator(image_dir=image_dir, labels_df=labels_df, batch_size=32, target_size=(128, 128))

# Load the pretrained models
body_part_model = tf.keras.models.load_model('body_part_model.h5')
fracture_classification_model = tf.keras.models.load_model('fracture_classification_model_with_densenet169.h5')

# Function to make predictions using both models (body part and fracture)
def predict_with_models(images):
    # Predict body part (Humerus or Shoulder)
    body_part_preds = body_part_model.predict(images)
    body_part_preds = np.argmax(body_part_preds, axis=1)  # Convert to 0 (Humerus) or 1 (Shoulder)

    # Predict fracture status (Fractured or Non-Fractured)
    fracture_preds = fracture_classification_model.predict(images)
    fracture_preds = (fracture_preds >= 0.5).astype(int)  # 1 for Fractured, 0 for Non-Fractured

    return body_part_preds, fracture_preds

# Get a batch of images and labels from the generator
images, labels = next(iter(image_generator))  # Fetch one batch of data

# Extract ground truth labels
true_body_parts = labels[:, 0]  # True body part labels
true_fractures = labels[:, 1]   # True fracture labels

# Make predictions
body_part_preds, fracture_preds = predict_with_models(images)

# Calculate accuracy for body part classification
body_part_accuracy = accuracy_score(true_body_parts, body_part_preds)
print("Body Part Classification Accuracy:", body_part_accuracy)

# Calculate accuracy for fracture classification
fracture_accuracy = accuracy_score(true_fractures, fracture_preds)
print("Fracture Classification Accuracy:", fracture_accuracy)


# Function to visualize predictions with true labels
# Correct the comparison to extract the scalar value from the array
# Correcting the fracture prediction extraction
# Function to visualize predictions with true labels
import matplotlib.pyplot as plt

def visualize_predictions(generator, body_part_model, fracture_classification_model, num_images=5):
    # Get a batch of images from the generator
    images, labels = next(iter(generator))

    # Make predictions for body part and fracture
    body_part_preds = body_part_model.predict(images)
    fracture_preds = fracture_classification_model.predict(images)

    # Visualize some predictions
    for i in range(num_images):
        plt.figure(figsize=(4, 4))

        # Plot the image
        plt.imshow(images[i])

        # Get the true labels for body part and fracture
        true_body_part = 'Humerus' if labels[i][0] == 0 else 'Shoulder'
        true_fracture = 'Fractured' if labels[i][1] == 1 else 'Non-Fractured'

        # Get the predicted labels for body part and fracture
        pred_body_part = 'Humerus' if body_part_preds[i] < 0.5 else 'Shoulder'

        # Extract the scalar value from fracture_preds[i]
        pred_fracture = 'Fractured' if fracture_preds[i][0] >= 0.5 else 'Non-Fractured'

        # Add the labels as text on the image
        plt.title(f"True: {true_body_part}, {true_fracture}\nPred: {pred_body_part}, {pred_fracture}")
        plt.axis('off')
        plt.show()

        # Optionally print prediction details for debugging
        print(f"Image {i}: True Body Part - {true_body_part}, Predicted Body Part - {pred_body_part}")
        print(f"Image {i}: True Fracture - {true_fracture}, Predicted Fracture - {pred_fracture}")


# Ensure image_generator is created before the function call
image_generator = CustomImageGenerator(image_dir=image_dir, labels_df=labels_df, batch_size=32, target_size=(128, 128))

# Visualize predictions after training
visualize_predictions(image_generator, body_part_model, fracture_classification_model, num_images=10)
