import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, classification_report

# Paths to test directory
test_dir = r'C:\Users\BALA\Downloads\TestImageHumerus'  # Path to your test images

# ImageDataGenerator for loading test images
test_datagen = ImageDataGenerator(rescale=1.0/255)  # Rescale the pixel values

# Image generator for loading the test images
test_generator = test_datagen.flow_from_directory(
    test_dir,
    target_size=(128, 128),
    batch_size=32,
    class_mode='binary',
    shuffle=False  # Don't shuffle for test data to maintain order
)

# Load the trained model (replace 'model_name.h5' with your actual model file name)
model = tf.keras.models.load_model('bone_model_basic_cnn_FINAL.h5')  # Load your trained model

# Print the model summary
print("\nModel Summary:")
model.summary()  # This will print the details of the model architecture

# Evaluate the model on test data
test_loss, test_accuracy = model.evaluate(test_generator)
print(f'\nTest Accuracy: {test_accuracy:.4f}, Test Loss: {test_loss:.4f}')

# Predictions on test data
test_generator.reset()  # Reset generator to ensure it starts from the beginning
predictions = model.predict(test_generator)
predicted_classes = (predictions > 0.5).astype("int32")  # Convert probabilities to binary

# Get the true labels from the test generator
true_labels = test_generator.classes

# Show predicted classes
print("\nPredicted Classes (1 for fractured, 0 for non-fractured):")
print(predicted_classes.flatten())

# Confusion Matrix
cm = confusion_matrix(true_labels, predicted_classes)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['Not Fractured', 'Fractured'])
disp.plot(cmap=plt.cm.Blues)
plt.show()

# Classification Report
print("\nClassification Report:")
print(classification_report(true_labels, predicted_classes, target_names=['Not Fractured', 'Fractured']))
